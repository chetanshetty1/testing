package Objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Addcart
{
WebDriver driver;
public Addcart(WebDriver driver)
{
this.driver=driver;
PageFactory.initElements(driver,this);
}
@FindBy(xpath="/html/body/div[4]/main/div[2]/div/ul/li[5]/div/a")
WebElement product;

@FindBy(xpath="/html/body/div[4]/main/div[1]/div/div/div[2]/div[1]/form/div[2]/button/span[1]")
WebElement cart;

@FindBy(xpath="/html/body/div[2]/div/a")
WebElement pop;


public WebElement  product()
{
	return  product;
}
public WebElement cart()
{
	return  cart;
}
public WebElement pop()
{
	return  pop;
}
}
