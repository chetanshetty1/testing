package Objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Paymentdetail {
	WebDriver driver;
	public Paymentdetail(WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="//*[@id=\"checkout_email_or_phone\"]")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"checkout_shipping_address_first_name\"]")
	WebElement Firstname;
	
	@FindBy(xpath="//*[@id=\"checkout_shipping_address_last_name\"]")
	WebElement Lastname;
	
	@FindBy(xpath="//*[@id=\"checkout_shipping_address_address1\"]")
	WebElement Address;
	
	@FindBy(xpath="//*[@id=\"checkout_shipping_address_address2\"]")
	WebElement Address1;
	
	@FindBy(xpath="//*[@id=\"checkout_shipping_address_city\"]")
	WebElement city;
	
	@FindBy(id="checkout_shipping_address_province")
	WebElement state;
	
	@FindBy(xpath="//*[@id=\"checkout_shipping_address_zip\"]")
	WebElement pincode;
	
	@FindBy(xpath="//*[@id=\"continue_button\"]") 
	WebElement shipping;
	
	@FindBy(xpath="//*[@id=\"continue_button\"]")
	WebElement conshipping;
	
	@FindBy(xpath="//*[@id=\"continue_button\"]")
	WebElement completeorder;
	
	public WebElement email()
    {
    	return email;
    }
	
	public WebElement Firstname()
    {
    	return Firstname;
    }
	

	public WebElement Lastname()
    {
    	return Lastname;
    }
	
	public WebElement Address()
    {
    	return Address;
    }
	
	public WebElement Address1()
    {
    	return Address1;
    }
	public WebElement city()
    {
    	return city;
    }
	
	public WebElement state()
    {
    	return state;
    }
	
	public WebElement  pincode()
    {
    	return  pincode;
    }
	
	public WebElement  shipping()
    {
    	return  shipping;
    }
	
	public WebElement  conshipping()
    {
    	return  conshipping;
    }
	
	public WebElement  completeorder()
    {
    	return  completeorder;
    }
	
}
