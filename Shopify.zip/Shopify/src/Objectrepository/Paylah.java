package Objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Paylah {
	WebDriver driver;
	public Paylah(WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="//*[@id=\"paylah_phone\"]")
	WebElement Mobileno;
	
	@FindBy(xpath="//*[@id=\"tel_submit\"]")
	WebElement Pay;
	
	@FindBy(xpath="/html/body/div[1]/div[2]/div[2]/a")
	WebElement cancel;

	@FindBy(xpath="//*[@id=\"main-header\"]")
	WebElement thank;
	
	@FindBy(xpath="/html/body/div[2]/div/div/main/div[1]/div/form/div[1]/div[1]/p")
	WebElement dec;
	
	@FindBy(xpath="/html/body/div[1]/div[2]/div[1]/form/div[2]/span")
	WebElement val;
	
	@FindBy(xpath="/html/body/div[2]/div/div/main/div[1]/div/form/div[1]/div[2]/div[1]/div/p")
	WebElement ddee;
	
	public WebElement Mobileno()
	{
		return  Mobileno;
	}
	
	public WebElement Pay()
	{
		return  Pay;
	}
	
	public WebElement thank()
	{
		return  thank;
	}
	
	public WebElement dec()
	{
		return  dec;
	}
	public WebElement cancel()
	{
		return  cancel;
	}
	public WebElement val()
	{
		return  val;
	}
	public WebElement ddee()
	{
		return  ddee;
	}
}
