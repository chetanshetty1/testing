package Objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Checkout {
	WebDriver driver;
	public Checkout(WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="/html/body/div[4]/main/div/div/form/div/div/div/div[3]/input[2]")
	WebElement check;
	public WebElement check()
	{
		return  check;
	}
	

}
