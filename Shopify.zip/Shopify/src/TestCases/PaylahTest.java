package TestCases;

import java.io.File;
import java.io.IOException;

//import java.io.File;

import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import Objectrepository.Addcart;
import Objectrepository.Checkout;
import Objectrepository.Paylah;
import Objectrepository.Paymentdetail;

public class PaylahTest {
 

@Test(enabled=true)
  public void paysuccess() {
	  
	  System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
		driver.get(" https://paylah-gateway-development.myshopify.com");
		driver.manage().window().maximize();
		Addcart add=new Addcart(driver);
		add.product().click();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		add.cart().click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div")));
		add.pop().click();
		Checkout ch=new Checkout(driver);
		ch.check().click();
		Paymentdetail pd=new Paymentdetail(driver);
		pd.email().sendKeys("gtu@gmail.com");
		pd.Firstname().sendKeys("ram");
		pd.Lastname().sendKeys("nm");
		pd.Address().sendKeys("rttr 8uii uiuiu 6 cross");
		pd.Address1().sendKeys("5th cross vgh tyg");
		pd.city().sendKeys("bank");
		Select sel=new Select(pd.state());
		sel.selectByVisibleText("Andhra Pradesh");
		pd.pincode().sendKeys("121212");
		pd.shipping().click();
		pd.conshipping().click();
		pd.completeorder().click();
		Paylah lh=new Paylah(driver);
		lh.Mobileno().sendKeys("99971008");
		lh.Pay().click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		String str=lh.thank().getText();
		System.out.println(str);
		String expectedTitle="Thank you ram!";
		 Assert.assertTrue(expectedTitle.equals(str));
		 driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		 driver.close();
  }
  
  @Test(enabled=true)
  public void paydecline() 
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\Chetan Kumar\\Documents\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
		driver.get(" https://paylah-gateway-development.myshopify.com");
		driver.manage().window().maximize();
		Addcart add=new Addcart(driver);
		add.product().click();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		add.cart().click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div")));
		add.pop().click();
		Checkout ch=new Checkout(driver);
		ch.check().click();
		Paymentdetail pd=new Paymentdetail(driver);
		pd.email().sendKeys("gtu@gmail.com");
		pd.Firstname().sendKeys("ram");
		pd.Lastname().sendKeys("nm");
		pd.Address().sendKeys("rttr 8uii uiuiu 6 cross");
		pd.Address1().sendKeys("5th cross vgh tyg");
		pd.city().sendKeys("bank");
		Select sel=new Select(pd.state());
		sel.selectByVisibleText("Andhra Pradesh");
		pd.pincode().sendKeys("121212");
		pd.shipping().click();
		pd.conshipping().click();
		pd.completeorder().click();
		Paylah lh=new Paylah(driver);
		lh.Mobileno().sendKeys("99971008");
		lh.Pay().click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		String str=lh.ddee().getText();
		System.out.println(str);
		String expectedTitle="Your payment can�t be processed for technical reasons. Try again or use a different payment method.";
		 Assert.assertTrue(expectedTitle.equals(str));
		 driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		 driver.close();
	  
  }
  @Test(enabled=true)
  public void paycancel() 
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\Chetan Kumar\\Documents\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
		driver.get(" https://paylah-gateway-development.myshopify.com");
		driver.manage().window().maximize();
		Addcart add=new Addcart(driver);
		add.product().click();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		add.cart().click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div")));
		add.pop().click();
		Checkout ch=new Checkout(driver);
		ch.check().click();
		Paymentdetail pd=new Paymentdetail(driver);
		pd.email().sendKeys("gtu@gmail.com");
		pd.Firstname().sendKeys("ram");
		pd.Lastname().sendKeys("nm");
		pd.Address().sendKeys("rttr 8uii uiuiu 6 cross");
		pd.Address1().sendKeys("5th cross vgh tyg");
		pd.city().sendKeys("bank");
		Select sel=new Select(pd.state());
		sel.selectByVisibleText("Andhra Pradesh");
		pd.pincode().sendKeys("121212");
		pd.shipping().click();
		pd.conshipping().click();
		pd.completeorder().click();
		Paylah lh=new Paylah(driver);
		lh.Mobileno().sendKeys("99971008");
		lh.cancel().click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		String str=lh.dec().getText();
		System.out.println(str);
		String expectedTitle="All transactions are secure and encrypted.";
		 Assert.assertTrue(expectedTitle.equals(str));
		 driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		 driver.close();
	   
  }
  
  @Test(enabled=true)
  public void validationmobileno() throws IOException
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\Chetan Kumar\\Documents\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
		driver.get(" https://paylah-gateway-development.myshopify.com");
		driver.manage().window().maximize();
		Addcart add=new Addcart(driver);
		add.product().click();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		add.cart().click();
		//driver.manage().timeouts().implicitlyWait(3, TimeUnit.MINUTES);
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/div")));
		add.pop().click();
		Checkout ch=new Checkout(driver);
		ch.check().click();
		Paymentdetail pd=new Paymentdetail(driver);
		pd.email().sendKeys("gtu@gmail.com");
		pd.Firstname().sendKeys("ram");
		pd.Lastname().sendKeys("nm");
		pd.Address().sendKeys("rttr 8uii uiuiu 6 cross");
		pd.Address1().sendKeys("5th cross vgh tyg");
		pd.city().sendKeys("bank");
		Select sel=new Select(pd.state());
		sel.selectByVisibleText("Andhra Pradesh");
		pd.pincode().sendKeys("121212");
		pd.shipping().click();
		pd.conshipping().click();
		pd.completeorder().click();
		Paylah lh=new Paylah(driver);
		lh.Mobileno().sendKeys("71008"); 
		lh.Pay().click();
		String str=lh.val().getText();
		System.out.println(str);
		String expectedTitle="Please enter a valid Singapore mobile number!";
		 if(expectedTitle.equals(str))
		 {
			 TakesScreenshot scrShot =((TakesScreenshot)driver);
			 File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
			 File DestFile=new File("C:\\Users\\Chetan Kumar\\Pictures\\Saved Pictures\\test.png");
	    	//FileUtils.copyFile(SrcFile, DestFile);
			 
			 FileUtils.copyFile(SrcFile, DestFile);
			 
	    	//System.out.println(str);
		 }
		 else {
			 driver.close();
		 }
		 
		// driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		 driver.close();
  }

}
