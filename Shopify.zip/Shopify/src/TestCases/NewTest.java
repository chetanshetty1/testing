package TestCases;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.WorkbookDocument;
import org.testng.annotations.Test;
import org.apache.poi.*;

import java.util.*;
import java.util.concurrent.TimeUnit;
public class NewTest {
  @Test
  public void College() throws AWTException, IOException, InterruptedException 
  {
	  ArrayList data=new ArrayList();
  System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
  WebDriver driver=new ChromeDriver();
	driver.get("http://collegewear-design-app.dev-fsit.com/wp-login.php?loggedout=true"); 
	driver.manage().window().maximize();
    driver.findElement(By.xpath("//*[@id=\"user_login\"]")).sendKeys("rekha.r@fortunesoftit.com");
	driver.findElement(By.xpath("//*[@id=\"user_pass\"]")).sendKeys(" X6q8PTD$USFE/f=\"");
		driver.findElement(By.xpath("//*[@id=\"wp-submit\"]")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[9]/a/div[3]")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[9]/ul/li[6]/a")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[5]/div[3]/div[1]/div/table/tbody/tr[2]/td[5]/a")).click();
		
		
		 File fs = new File("D:\\Book1.xlsx");
		 FileInputStream fis=new FileInputStream(fs);
		 XSSFWorkbook wb=new XSSFWorkbook(fis);
		 XSSFSheet sh1= wb.getSheet("Sheet1");
		 //Sheet sh1 = (Sheet) wb.getSheet("Sheet1"); 
		 Iterator rowit=sh1.iterator();
		 while(rowit.hasNext()) {
			 Row row=(Row)rowit.next();
			 Iterator cellItr=row.cellIterator();
			 while(cellItr.hasNext()) {
				 Cell cell1 =(Cell)cellItr.next();
				
				 switch(cell1.getCellType()){
	                case STRING:
	                    data.add(cell1.getStringCellValue());
	                    break;
	                case NUMERIC:data.add(cell1.getNumericCellValue());
	                   break;
	                default:break;
			 }
		 }
			 
		 }	
		 for(int i=0;i<data.size();i=i+2) { 

			
			 String name=(String) data.get(i);
			String path=(String) data.get(i+1);
			System.out.println(name+" "+path+"\n");
		
			
		 

		driver.findElement(By.xpath("//*[@id=\"tag-name\"]")).clear();
	driver.findElement(By.xpath("//*[@id=\"tag-name\"]")).sendKeys(name);
		
      driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[5]/div[4]/div[1]/div/div/form/div[4]/div[2]/button[1]")).click();
		driver.findElement(By.xpath("/html/body/div[5]/div[1]/div/div/div[3]/div/a[1]")).click();
		Thread.sleep(5000);
	driver.findElement(By.xpath("//*[@id=\"__wp-uploader-id-1\"]")).click();
	Thread.sleep(2000);
		StringSelection ss = new StringSelection(path);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
		Robot robot = new Robot();
       robot.keyPress(KeyEvent.VK_CONTROL);
       robot.keyPress(KeyEvent.VK_V);
     robot.keyRelease(KeyEvent.VK_V);
     robot.keyRelease(KeyEvent.VK_CONTROL);
     Thread.sleep(2000);
    robot.keyPress(KeyEvent.VK_ENTER);
     robot.keyRelease(KeyEvent.VK_ENTER);
     Thread.sleep(5000);
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
	driver.findElement(By.xpath("/html/body/div[5]/div[1]/div/div/div[5]/div/div[2]/button")).click();
	Thread.sleep(5000);
	
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
	driver.findElement(By.xpath("//*[@id=\"submit\"]")).click();
	Thread.sleep(5000);
	driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
		//i++;
		 }
  }
}
