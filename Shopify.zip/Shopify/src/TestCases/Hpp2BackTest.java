package TestCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class Hpp2BackTest {
	WebDriver driver;
  @Test
  public void Login() throws InterruptedException 
  {
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  
	  WebElement Element = driver.findElement(By.xpath("//*[@id=\"email\"]")); 
	  Thread.sleep(9000);
	  js.executeScript("arguments[0].scrollIntoView();", Element);
	  Thread.sleep(9000);
	  driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("admin@dbskfc.com");
	  driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("admin@123");
	  driver.findElement(By.xpath("/html/body/form/div/button")).click();
	  
  }
  @BeforeMethod
  public void beforeMethod() 
  {
	  System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	     driver =new ChromeDriver();
		driver.get("http://192.168.1.92/dbs_admin/admin/transactions");
		driver.manage().window().maximize();
  }

  @AfterMethod
  public void afterMethod()
  {
	  
  }

}
