package Testcase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Objectrepository.Tripadvisor;

public class MaintripTest {
  @Test
  public void f() throws InterruptedException 
  {
  WebDriver driver;
  {
	  System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		 driver=new ChromeDriver();
			driver.get("https://www.tripadvisor.in/");
			driver.manage().window().maximize();
			Tripadvisor search=new Tripadvisor(driver);
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			search.searchproduct().click();
			search.searchproduct1().sendKeys("club Mahindra");
			search.clicksearch().click();
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			search.clickclub().click();
			driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
			//driver.manage().timeouts().pageLoadTimeout(5000, TimeUnit.SECONDS);
			//driver.findElement(By.xpath("/html/body/div[2]/div[1]/div/div[6]/div/div/div/div[1]/div[1]")).click();
			driver.findElement(By.xpath("//*[@id=\"HEADING\"]")).click();
			driver.findElement(By.xpath("/html/body/div[2]/div[1]/div/div[6]/div/div/div/div[2]/div/div[1]/div[1]/div/div/span/span/span[2]/span")).click(); 
			  //Thread.sleep(9000);
			//JavascriptExecutor js = (JavascriptExecutor) driver;
			  
			 // WebElement Element = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[2]/div[7]/div/div[1]/div[1]/div/div/div[2]/div/div[2]/div/div[1]/a")); 
			  //Thread.sleep(9000);
			  //js.executeScript("arguments[0].scrollIntoView();", Element);
//			search.writereview().click();
			
  }
}
}