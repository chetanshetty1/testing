package Objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Tripadvisor {
	WebDriver driver;
	public Tripadvisor (WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="/html/body/div[1]/div/div[1]/div[2]/div/div/div/div/div[2]/div/div/div[7]/div/span[2]")
	WebElement searchproduct;
	
	@FindBy(xpath="//*[@id=\"mainSearch\"]")
	WebElement searchproduct1;
	
	@FindBy(xpath="//*[@id=\"SEARCH_BUTTON\"]")
	WebElement clicksearch;

	@FindBy(xpath="/html/body/div[2]/div/div[2]/div/div/div/div/div[1]/div/div[1]/div/div[3]/div/div[1]/div/div[2]/div/div/div[1]/div/div/div/div[2]/div/div[1]/span")
	WebElement clickclub;

	@FindBy(xpath="/html/body/div[2]/div[2]/div[2]/div[7]/div/div[1]/div[1]/div/div/div[2]/div/div[2]/div/div[1]/a")
	WebElement writereview;


	public WebElement  searchproduct()
	{
		return  searchproduct;
	}
	public WebElement  searchproduct1()
	{
		return  searchproduct1;
	}
	
	public WebElement  clicksearch()
	{
		return  clicksearch;
	}
	public WebElement  clickclub()
	{
		return  clickclub;
	}
	public WebElement  writereview()
	{
		return  writereview;
	}
}
