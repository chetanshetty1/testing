package Testcase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import objectrepository.amazonsearch;
import objectrepository.flipcartsearch;

public class AmazonandFlipcartTest {
  @Test
  public void f() throws InterruptedException {
}
  WebDriver driver;
  {
	  
	 
	  System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	 driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		amazonsearch search=new amazonsearch(driver);
		search.searchproduct().sendKeys("iPhoneXR(64GB)-Yellow");
		search.clicksearch().click();
		//search.clickproduct().click();
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//WebDriverWait wait = new WebDriverWait(driver,200);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[4]/div[2]/div[4]/div[7]/div[7]/div/div/div[1]/div/div/div[2]/div/div[1]/a/h5/div[2]/div/span[1]")));
		//String amzprice=search.getprice().getText();
		WebElement em=search.clickproduct();
		
		String amzprice=em.getText().replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(amzprice);
		driver.close();
		driver=new ChromeDriver();
			driver.get("https://www.flipkart.com/?gclid=EAIaIQobChMIh9b99u2g5gIVESUrCh0rkwN9EAAYASAAEgIiyfD_BwE&ef_id=EAIaIQobChMIh9b99u2g5gIVESUrCh0rkwN9EAAYASAAEgIiyfD_BwE:G:s&s_kwcid=AL!739!3!326555007752!e!!g!!flipkart&semcmpid=sem_8024046704_brand_eta_goog");
			driver.manage().window().maximize();
			flipcartsearch searc=new flipcartsearch(driver);
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			searc.closewindow().click();
			searc.searchproduct().sendKeys("Apple iPhone XR (Yellow, 128 GB)");
			searc.clicksearch().click();
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			//searc.clickproduct().click();
			//String flipprice=search.getprice().getText();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			WebElement em1=searc.price();
			String flipprice=em1.getText().replaceAll("[^a-zA-Z0-9]", "");
			System.out.println("value----"+flipprice);
			String url1="https://www.amazon.in/";
			String url2="https://www.flipkart.com/?gclid=EAIaIQobChMIh9b99u2g5gIVESUrCh0rkwN9EAAYASAAEgIiyfD_BwE&ef_id=EAIaIQobChMIh9b99u2g5gIVESUrCh0rkwN9EAAYASAAEgIiyfD_BwE:G:s&s_kwcid=AL!739!3!326555007752!e!!g!!flipkart&semcmpid=sem_8024046704_brand_eta_goog";
			String array[][]= {{url1,amzprice},{url2,flipprice}}; 
			int i=Integer.parseInt(array[0][1]);  
			int j=Integer.parseInt(array[1][1]);
			System.out.println(i+"--"+j);
			if(i < j)
			{
				System.out.println(array[0][0]+" has less Price of an Iphone");
			}
			else
			{
				System.out.println(array[1][0]);	
			}
  }
}
