package objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class flipcartsearch {
	WebDriver driver;
	public flipcartsearch (WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="/html/body/div[1]/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input")
	WebElement searchproduct;
	@FindBy(xpath="/html/body/div[2]/div/div/button")
	WebElement closewindow;
	///html/body/div[2]/div/div/button
	@FindBy(xpath="/html/body/div[1]/div/div[1]/div[1]/div[2]/div[2]/form/div/button")
	WebElement clicksearch;

	@FindBy(xpath="/html/body/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[1]/div[1]/div/div/img")
	WebElement clickproduct;

	@FindBy(xpath="/html/body/div[1]/div/div[3]/div[2]/div/div[2]/div[2]/div/div/div/a/div[2]/div[2]/div[1]/div/div[1]")
	WebElement price;


	public WebElement  searchproduct()
	{
		return  searchproduct;
	}
	public WebElement  closewindow()
	{
		return  closewindow;
	}
	
	public WebElement clickproduct()
	{
		return  clickproduct;
	}
	
	public WebElement price()
	{
		return  price;
	}
	public WebElement clicksearch()
	{
		return  clicksearch;
	}
}
