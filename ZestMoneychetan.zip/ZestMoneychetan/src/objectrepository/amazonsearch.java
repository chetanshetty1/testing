package objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class amazonsearch 
{
	WebDriver driver;
	public amazonsearch (WebDriver driver)
	{
	this.driver=driver;
	PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="//*[@id=\"twotabsearchtextbox\"]")
	WebElement searchproduct;
	
	@FindBy(xpath="/html/body/div[1]/header/div/div[1]/div[3]/div/form/div[2]/div/input")
	WebElement clicksearch;

	@FindBy(xpath="/html/body/div[1]/div[2]/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div/div/a/span[1]/span[2]/span[2]")
	WebElement clickproduct;

	@FindBy(xpath="/html/body/div[4]/div[2]/div[4]/div[9]/div[13]/div/table/tbody/tr[2]/td[2]/span[1]")
	WebElement getprice;


	public WebElement  searchproduct()
	{
		return  searchproduct;
	}
	
	
	
	public WebElement clickproduct()
	{
		return  clickproduct;
	}
	
	public WebElement getprice()
	{
		return  getprice;
	}
	public WebElement clicksearch()
	{
		return  clicksearch;
	}
	
}
